import { useEffect, useState } from "react";
import { View, Text, TextInput, Button, Alert, FlatList, ScrollView, KeyboardAvoidingView, Platform } from "react-native";
import {
  createProduct,
  getProducts,
  deleteProduct,
  updateProduct,
} from "../firebase/productService";

export default function HomeScreen({ navigation, route }) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [barcode, setBarcode] = useState("");
  const [products, setProducts] = useState([]);
  const [editingProductId, setEditingProductId] = useState(null);

  async function loadProducts() {
    try {
      const productList = await getProducts();
      setProducts(productList);
    } catch (error) {
      Alert.alert("Erro", "Não foi possível carregar os produtos.");
    }
  }

  useEffect(() => {
    loadProducts();
  }, []);

  // PRESERVAR DADOS DO SCANNER
  useEffect(() => {
    if (route.params?.scannedBarcode) {
      setBarcode(String(route.params.scannedBarcode));
    }
  }, [route.params]);

  function clearForm() {
    setName("");
    setPrice("");
    setBarcode("");
    setEditingProductId(null);
  }

  async function handleSaveProduct() {
    if (!name.trim() || !price.trim()) {
      Alert.alert("Atenção", "Preencha nome e preço do produto.");
      return;
    }

    const productData = {
      name: name.trim(),
      price: price.trim(),
      barcode: barcode ? String(barcode).trim() : "",
    };

    try {
      if (editingProductId) {
        await updateProduct(editingProductId, productData);
        Alert.alert("Sucesso", "Produto atualizado!");
      } else {
        await createProduct(productData);
        Alert.alert("Sucesso", "Produto cadastrado!");
      }

      clearForm();
      await loadProducts();
    } catch (error) {
      Alert.alert("Erro", "Erro ao salvar produto.");
    }
  }

  function handleEditProduct(product) {
    setName(product.name || "");
    setPrice(product.price || "");
    setBarcode(product.barcode || "");
    setEditingProductId(product.id);
  }

  function handleCancelEdit() {
    clearForm();
  }

  function handleDeleteProduct(productId) {
    Alert.alert(
      "Confirmar",
      "Deseja excluir este produto?",
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          onPress: async () => {
            try {
              await deleteProduct(productId);
              if (editingProductId === productId) clearForm();
              loadProducts();
            } catch {
              Alert.alert("Erro", "Erro ao excluir.");
            }
          },
        },
      ]
    );
  }

  function handleOpenScanner() {
    navigation.navigate("BarcodeScanner");
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={{ fontSize: 24, marginTop: 40, marginBottom: 20 }}>
          Bem-vindo!
        </Text>

        <Button title="Ler código de barras" onPress={handleOpenScanner} />

        <TextInput
          placeholder="Nome do produto"
          value={name}
          onChangeText={setName}
          style={{ borderWidth: 1, marginTop: 20, padding: 10 }}
        />

        <TextInput
          placeholder="Preço"
          value={price}
          onChangeText={setPrice}
          keyboardType="numeric"
          style={{ borderWidth: 1, marginTop: 10, padding: 10 }}
        />

        <TextInput
          placeholder="Código de barras"
          value={barcode}
          onChangeText={setBarcode}
          style={{ borderWidth: 1, marginTop: 10, padding: 10 }}
        />

        <Button
          title={editingProductId ? "Atualizar" : "Cadastrar"}
          onPress={handleSaveProduct}
        />

        {editingProductId && (
          <Button title="Cancelar" onPress={handleCancelEdit} />
        )}

        <Text style={{ fontSize: 20, marginTop: 30 }}>
          Produtos
        </Text>

        <FlatList
          data={products}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <View style={{ borderWidth: 1, padding: 10, marginTop: 10 }}>
              <Text>{item.name}</Text>
              <Text>{item.price}</Text>
              <Text>{item.barcode}</Text>

              <Button title="Editar" onPress={() => handleEditProduct(item)} />
              <Button title="Excluir" onPress={() => handleDeleteProduct(item.id)} />
            </View>
          )}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
